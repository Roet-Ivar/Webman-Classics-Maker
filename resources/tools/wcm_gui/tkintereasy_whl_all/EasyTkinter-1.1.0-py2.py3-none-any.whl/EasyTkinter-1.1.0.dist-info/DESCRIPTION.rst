***************
EasyTkinter
***************

EasyTkinter is a python module for simplifying basic tkinter programs.

Please see the documentation attached.

If anyone would like to improve/add features, feel free to fork - `Github <https://github.com/JoetheBellum/EasyTkinter>`_


