# Webman-Classics-Maker
A tool for PS3 that makes PKG shortcuts for ISO files using webman web commands, created by aldostools.

Read more about webman web commands here:
http://www.psx-place.com/threads/webman-mod-web-commands.1508/

Builds can be downloaded from here:
https://www.dropbox.com/sh/g3ojukonqja73fv/AAAtfEYNV3YhjHtlcwEJQZ3sa?dl=0

Webman Classics Maker take great help from naehrwert's scetool 0.2.9:
https://github.com/naehrwert/scetool


------------------------------------------------------------------------
How to build your own binaries

Install python 2.7 + pyinstaller lib, run the pyinstaller-scipts located in: /Webman-Classics-Maker/resources/tools/util_scripts/_pyinstaller_scripts/
